<div class="mx-auto w-[100%] md:w-[80%]">
    <div class=" flex flex-col lg:flex-row lg:space-x-4 px-4  shadow-xl bg-blue-100 py-16 ">
        @livewire('user.post-list')
    </div>
</div>
