<div class="bg-slate-300 flex flex-col items-center px-4 rounded-md my-2 py-2">
    <p class="font-semibold text-[20px] capitalize">{{$name}}</p>
    <p class="text-[15px]">{{$age_range?? '-'}}</p>
    <p class="text-[15px]">{{$price}}</p>
    <p class="text-[15px]">{{$count}}</p>
    <p class="text-[15px]">{{$total}}</p>
</div>
