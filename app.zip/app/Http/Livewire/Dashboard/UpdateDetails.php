<?php

namespace App\Http\Livewire\Dashboard;

use App\Models\User;
use Worldpay\Worldpay;
use Livewire\Component;
use App\Models\MembershipClub;
use App\Models\RequestActivation;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Jantinnerezo\LivewireAlert\LivewireAlert;

class UpdateDetails extends Component
{
    use LivewireAlert;
    public $countries,$club,$club_website,$club_facebook_link,$club_instagram_link,
    $club_twitter_link,$club_venue,$club_zip_code,$club_language,$number_of_supporters,$last_supporter_joined_date,
    $ticket_contact_name,$ticket_contact_number,$ticket_contact_email, $ticket_address,$club_members;
    protected $rules = [
        'club.name' => 'required',
        'club.country' => 'required|string',
        'club.club_email' => 'required|email',
        'club.club_mobile' => 'required|string',
    ];
    public function mount(){
        // $worldpay = new Worldpay('your-test-service-key');
        // dd($worldpay);
        $this->countries = DB::table('countries')->pluck('name');
        $this->club = MembershipClub::whereUserId(Auth::id())->first();
        $this->club_website = $this->club->club_website;
        $this->club_facebook_link = $this->club->club_facebook_link;
        $this->club_instagram_link = $this->club->club_instagram_link;
        $this->club_twitter_link = $this->club->club_twitter_link;
        $this->club_venue = $this->club->club_venue;
        $this->club_zip_code = $this->club->club_zip_code;
        $this->club_language = $this->club->club_language;
        $this->last_supporter_joined_date = User::whereClubId($this->club->id)->latest()->first()->created_at?? null;
        $this->ticket_contact_name = $this->club->ticket_contact_name;
        $this->number_of_supporters = User::whereClubId($this->club->id)->count();
        $this->ticket_contact_number = $this->club->ticket_contact_number;
        $this->ticket_contact_email = $this->club->ticket_contact_email;
        $this->ticket_address = $this->club->ticket_address;
    }

    public function Activate()
    {
        $activated = RequestActivation::whereUserId(Auth::id())->first();
        // dd($activated);
        if(!$activated){
            $request = new RequestActivation();
            $request->user_id = Auth::id();
            $request->save();
            $this->alert('success', 'Request sent successfully.');
        }
    }
    public function updateClubInfo(){
        $validatedData = $this->validate();
        $this->club->club_website = $this->club_website;
        $this->club->club_facebook_link = $this->club_facebook_link;
        $this->club->club_instagram_link = $this->club_instagram_link;
        $this->club->club_twitter_link = $this->club_twitter_link;
        $this->club->club_venue = $this->club_venue;
        $this->club->club_zip_code = $this->club_zip_code;
        $this->club->club_language = $this->club_language;
        $this->club->last_supporter_joined_date = $this->last_supporter_joined_date;
        $this->club->ticket_contact_name = $this->ticket_contact_name;
        $this->club->ticket_contact_number = $this->ticket_contact_number;
        $this->club->ticket_contact_email = $this->ticket_contact_email;
        $this->club->ticket_address = $this->ticket_address;

        $this->club->save();
        $this->alert('success', 'Information updated successfully.');
    }
    public function render()
    {
        return view('livewire.dashboard.update-details')->layout('layouts.dashmain');
    }
}
