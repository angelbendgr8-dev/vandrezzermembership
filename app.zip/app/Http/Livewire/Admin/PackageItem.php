<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class PackageItem extends Component
{
    public $package;
    public function render()
    {
        return view('livewire.admin.package-item');
    }
}
